#include <metal/config.h>

struct metal_state {
    struct metal_common_state common;
};
