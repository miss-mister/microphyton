Q(example_package.foo)
Q(example_package.foo.bar)
