.. _rp2_intro:

Getting started with MicroPython on the RP2xxx
==============================================

Let's get started!

.. toctree::
    :maxdepth: 1

    pio.rst
